# Dinothawr Sokoban

[Dinothawr](https://github.com/Themaister/Dinothawr), but it's the classic [Sokoban](https://en.wikipedia.org/wiki/Sokoban).

![Screenshot](screenshot.png)

## Contribute

Right now, it only implements the first few levels, would love to see this grow! Feel free to open up [Tiled](https://www.mapeditor.org) and have your hack at adding more levels.

## Credits

- Agnes Heyer
- Hans-Kristian Arntzen
- Rob Loach
